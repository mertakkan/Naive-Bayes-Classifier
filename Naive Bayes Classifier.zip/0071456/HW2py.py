#!/usr/bin/env python
# coding: utf-8

# In[212]:


import pandas as pd
import numpy as np
import math
from sklearn.metrics import confusion_matrix


# In[213]:


images = pd.read_csv('hw02_images.csv',header=None)
labels = pd.read_csv('hw02_labels.csv',header=None)


# In[214]:


train_x = images.iloc[0:30000]
test_x = images.iloc[-5000:]
train_y = labels.iloc[0:30000]
test_y = labels.iloc[-5000:]


# In[215]:


tshirt_ds = train_x.iloc[train_y[train_y[0]==1].index,:]
dress_ds = train_x.iloc[train_y[train_y[0]==2].index,:]
coat_ds = train_x.iloc[train_y[train_y[0]==3].index,:]
shirt_ds = train_x.iloc[train_y[train_y[0]==4].index,:]
bag_ds = train_x.iloc[train_y[train_y[0]==5].index,:]


# In[229]:


class_means = [tshirt_ds.apply(lambda x : np.array(x).mean()), dress_ds.apply(lambda x : np.array(x).mean()),
              coat_ds.apply(lambda x : np.array(x).mean()), shirt_ds.apply(lambda x : np.array(x).mean()),
              bag_ds.apply(lambda x : np.array(x).mean())]
print(class_means)


# In[230]:


class_deviations = [tshirt_ds.apply(lambda x : np.array(x).std()), dress_ds.apply(lambda x : np.array(x).std()),
              coat_ds.apply(lambda x : np.array(x).std()), shirt_ds.apply(lambda x : np.array(x).std()),
              bag_ds.apply(lambda x : np.array(x).std())]
print(class_deviations)


# In[231]:


class_priors = (len(train_y[train_y[0]==1]) / len(train_y),len(train_y[train_y[0]==2]) / len(train_y),
         len(train_y[train_y[0]==3]) / len(train_y), len(train_y[train_y[0]==4]) / len(train_y),
         len(train_y[train_y[0]==5]) / len(train_y))
print(class_priors)


# In[232]:


K = np.max(train_y.to_numpy())
data_interval = np.linspace(-7, +7, 784)
train_y_hat1 = [- 0.5 * np.log(2 * math.pi * class_deviations[0]**2) 
                         - 0.5 * (data_interval - class_means[0])**2 / class_deviations[0]**2 
                         + np.log(class_priors[0])]
train_y_hat2 = [- 0.5 * np.log(2 * math.pi * class_deviations[1]**2) 
                         - 0.5 * (data_interval - class_means[1])**2 / class_deviations[1]**2 
                         + np.log(class_priors[1])]
train_y_hat3 = [- 0.5 * np.log(2 * math.pi * class_deviations[2]**2) 
                         - 0.5 * (data_interval - class_means[2])**2 / class_deviations[2]**2 
                         + np.log(class_priors[2])]
train_y_hat4 = [- 0.5 * np.log(2 * math.pi * class_deviations[3]**2) 
                         - 0.5 * (data_interval - class_means[3])**2 / class_deviations[3]**2 
                         + np.log(class_priors[3])]
train_y_hat5 = [- 0.5 * np.log(2 * math.pi * class_deviations[4]**2) 
                         - 0.5 * (data_interval - class_means[4])**2 / class_deviations[4]**2 
                         + np.log(class_priors[4])]

train_y_hat = []
train_y_hat.append(train_y_hat1)
train_y_hat.append(train_y_hat2)
train_y_hat.append(train_y_hat3)
train_y_hat.append(train_y_hat4)
train_y_hat.append(train_y_hat5)


# In[233]:


confusion_matrix = pd.crosstab(train_y_hat, train_y, rownames=['y_truth'], colnames=['y_pred'],margins=True)
print(confusion_matrix)


# In[ ]:





# In[ ]:





# In[ ]:




